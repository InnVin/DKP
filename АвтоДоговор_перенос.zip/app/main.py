from __future__ import annotations

import shutil
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import database
from .ai_ocr import recognize_images, status as ai_status
from .excel_service import create_contract
from .ocr import recognize

ROOT = Path(__file__).resolve().parents[1]
STATIC_DIR = ROOT / "app" / "static"
ALLOWED_DOCUMENT_TYPES = {"auto", "seller_passport", "buyer_passport", "pts", "sts", "old_contract", "other"}
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff", ".pdf"}


@asynccontextmanager
async def lifespan(_: FastAPI):
    database.init_db()
    yield


app = FastAPI(title="АвтоДоговор", version="0.1.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.middleware("http")
async def disable_browser_cache(request, call_next):
    response = await call_next(request)
    if request.url.path == "/" or request.url.path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
    return response


class DealPayload(BaseModel):
    deal_id: int | None = None
    data: dict[str, Any]


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "database": str(database.DB_PATH),
        "ocr": ai_status(),
        "version": app.version,
    }


@app.get("/api/deals")
def list_deals(q: str = "") -> list[dict[str, Any]]:
    return database.search_deals(q)


@app.get("/api/deals/{deal_id}")
def read_deal(deal_id: int) -> dict[str, Any]:
    deal = database.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Сделка не найдена")
    return deal


@app.post("/api/deals")
def write_deal(payload: DealPayload) -> dict[str, Any]:
    try:
        deal_id = database.save_deal(payload.data, payload.deal_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    return {"id": deal_id, "message": "Сделка сохранена"}


@app.post("/api/deals/{deal_id}/documents")
async def upload_document(
    deal_id: int,
    document_type: str = Form(...),
    file: UploadFile = File(...),
) -> dict[str, Any]:
    if not database.get_deal(deal_id):
        raise HTTPException(404, "Сначала сохраните карточку сделки")
    if document_type not in ALLOWED_DOCUMENT_TYPES:
        raise HTTPException(400, "Неизвестный тип документа")

    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, "Поддерживаются изображения и PDF")

    folder = database.UPLOAD_DIR / str(deal_id)
    folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"{uuid.uuid4().hex}{suffix}"
    with stored.open("wb") as destination:
        shutil.copyfileobj(file.file, destination)

    engine = ai_status()
    if suffix != ".pdf" and engine.get("available") and engine.get("installed"):
        ai_result = recognize_images([stored], document_type)
        result = {
            "status": "ok",
            "fields": ai_result.get("fields", {}),
            "field_meta": ai_result.get("field_meta", {}),
            "text": "",
            "note": "\n".join(ai_result.get("warnings", [])),
            "detected_type": ai_result.get("document_type", document_type),
            "effective_type": document_type,
            "pages": 1,
        }
    else:
        result = {
            "status": "waiting_ai",
            "fields": {},
            "field_meta": {},
            "text": "",
            "note": "Документ сохранён. Для точного распознавания установите и запустите локальный ИИ.",
            "detected_type": document_type,
            "effective_type": document_type,
            "pages": 1,
        }

    document_id = database.add_document(
        deal_id,
        document_type,
        file.filename or stored.name,
        str(stored),
        result.get("text", ""),
        result.get("status", "unknown"),
    )
    return {
        "document_id": document_id,
        "fields": result.get("fields", {}),
        "field_meta": result.get("field_meta", {}),
        "note": result.get("note", ""),
        "status": result.get("status", ""),
        "detected_type": result.get("detected_type", document_type),
        "effective_type": result.get("effective_type", document_type),
        "pages": result.get("pages", 1),
    }


@app.get("/api/documents/{document_id}")
def download_document(document_id: int) -> FileResponse:
    path = database.get_document_path(document_id)
    if not path or not path.exists():
        raise HTTPException(404, "Файл не найден")
    return FileResponse(path)


@app.post("/api/deals/{deal_id}/reprocess")
def reprocess_documents(deal_id: int) -> dict[str, Any]:
    deal = database.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Сделка не найдена")
    documents = database.get_deal_documents(deal_id)
    engine = ai_status()
    if not engine.get("available") or not engine.get("installed"):
        raise HTTPException(
            503,
            "Локальный ИИ не готов. Запустите «Установить ИИ.bat», затем повторите.",
        )
    combined_fields: dict[str, str] = {}
    combined_meta: dict[str, dict[str, Any]] = {}
    notes: list[str] = []
    processed = 0
    grouped: dict[str, list[dict[str, Any]]] = {}
    for document in documents:
        grouped.setdefault(document["document_type"], []).append(document)
    for document_type, group in grouped.items():
        image_documents = [
            document
            for document in group
            if Path(document["stored_path"]).exists()
            and Path(document["stored_path"]).suffix.lower() != ".pdf"
        ]
        if not image_documents:
            notes.append(f"{document_type}: PDF будет подключён к локальному ИИ следующим этапом.")
            continue
        result = recognize_images(
            [Path(document["stored_path"]) for document in image_documents],
            document_type,
        )
        combined_fields.update(result.get("fields", {}))
        combined_meta.update(result.get("field_meta", {}))
        notes.extend(result.get("warnings", []))
        for document in image_documents:
            database.update_document_ocr(document["id"], "", "ai_processed")
            processed += 1
    return {
        "processed": processed,
        "fields": combined_fields,
        "field_meta": combined_meta,
        "notes": "\n\n".join(notes),
    }


@app.post("/api/deals/{deal_id}/contract")
def make_contract(deal_id: int) -> dict[str, Any]:
    deal = database.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Сделка не найдена")
    deal.pop("_meta", None)
    deal.pop("documents", None)
    try:
        path, template_name = create_contract(deal_id, deal)
    except Exception as exc:
        raise HTTPException(500, f"Не удалось создать Excel: {exc}") from exc
    return {
        "filename": path.name,
        "download_url": f"/api/contracts/{path.name}",
        "template": template_name,
    }


@app.get("/api/contracts/{filename}")
def download_contract(filename: str) -> FileResponse:
    safe_name = Path(filename).name
    path = database.OUTPUT_DIR / safe_name
    if not path.exists():
        raise HTTPException(404, "Договор не найден")
    return FileResponse(path, filename=safe_name)
