const state = { dealId: null, documents: [] };
const form = document.querySelector("#dealForm");
const message = document.querySelector("#message");

function showMessage(text, error = false) {
  message.textContent = text;
  message.className = `message${error ? " error" : ""}`;
  clearTimeout(showMessage.timer);
  showMessage.timer = setTimeout(() => message.classList.add("hidden"), 5000);
}

function formData() {
  return Object.fromEntries(new FormData(form).entries());
}

function setForm(data = {}) {
  form.reset();
  for (const [key, value] of Object.entries(data)) {
    const field = form.elements.namedItem(key);
    if (field && typeof value !== "object") field.value = value || "";
  }
  state.documents = data.documents || [];
  renderDocuments();
  clearConfidence();
}

function clearConfidence() {
  form.querySelectorAll("input, textarea").forEach(field => {
    field.classList.remove("confidence-high", "confidence-medium", "confidence-low");
    field.removeAttribute("title");
  });
}

function applyConfidence(meta = {}) {
  clearConfidence();
  for (const [key, item] of Object.entries(meta)) {
    const field = form.elements.namedItem(key);
    if (!field) continue;
    const confidence = Number(item.confidence || 0);
    const level = confidence >= .85 ? "high" : confidence >= .65 ? "medium" : "low";
    field.classList.add(`confidence-${level}`);
    field.title = `Уверенность: ${Math.round(confidence * 100)}%. ${item.evidence || ""}`;
  }
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail || "Ошибка приложения");
  return body;
}

async function saveDeal(silent = false) {
  const result = await api("/api/deals", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ deal_id: state.dealId, data: formData() }),
  });
  state.dealId = result.id;
  document.querySelector("#dealBadge").textContent = `№ ${result.id}`;
  if (!silent) showMessage("Карточка сохранена");
  await loadArchive();
  return result.id;
}

async function loadArchive(query = "") {
  const rows = await api(`/api/deals?q=${encodeURIComponent(query)}`);
  const list = document.querySelector("#archiveList");
  list.innerHTML = rows.map(row => `
    <div class="archive-item ${row.id === state.dealId ? "active" : ""}" data-id="${row.id}">
      <strong>${escapeHtml(row.buyer_full_name || row.seller_full_name || "Без имени")}</strong>
      <span>${escapeHtml(row.vehicle_make_model || "Автомобиль не указан")}</span>
      <span>${escapeHtml([row.registration_plate, row.vin].filter(Boolean).join(" · "))}</span>
    </div>`).join("") || "<p>Архив пока пуст</p>";
}

async function openDeal(id) {
  const data = await api(`/api/deals/${id}`);
  state.dealId = id;
  setForm(data);
  document.querySelector("#dealBadge").textContent = `№ ${id}`;
  await loadArchive(document.querySelector("#archiveSearch").value);
}

function newDeal() {
  state.dealId = null;
  state.documents = [];
  setForm({ contract_date: new Date().toISOString().slice(0, 10), contract_place: "Якутск" });
  document.querySelector("#dealBadge").textContent = "Новая";
  document.querySelectorAll(".archive-item").forEach(x => x.classList.remove("active"));
}

async function uploadFiles(files) {
  if (!files.length) return;
  if (!state.dealId) await saveDeal(true);
  const type = document.querySelector("#documentType").value;
  for (const file of files) {
    const body = new FormData();
    body.append("document_type", type);
    body.append("file", file);
    showMessage(`Обрабатываю ${file.name}...`);
    const result = await api(`/api/deals/${state.dealId}/documents`, { method: "POST", body });
    for (const [key, value] of Object.entries(result.fields || {})) {
      const field = form.elements.namedItem(key);
      if (field && !field.value) field.value = value;
    }
    applyConfidence(result.field_meta || {});
    if (result.note) {
      const notes = form.elements.namedItem("notes");
      notes.value = [notes.value, result.note].filter(Boolean).join("\n\n");
    }
    state.documents.push({
      id: result.document_id,
      document_type: result.effective_type || type,
      original_name: file.name,
      ocr_status: result.status,
    });
    renderDocuments();
  }
  await saveDeal(true);
  showMessage("Документы сохранены. Проверьте заполненные поля.");
  document.querySelector("#documentFiles").value = "";
}

function renderDocuments() {
  const labels = {
    auto: "Автоопределение",
    seller_passport: "Паспорт продавца",
    buyer_passport: "Паспорт покупателя",
    pts: "ПТС",
    sts: "СТС",
    old_contract: "Старый договор",
    other: "Документ",
  };
  document.querySelector("#documentList").innerHTML = state.documents.map(doc =>
    `<a class="document-chip" href="/api/documents/${doc.id}" target="_blank">${labels[doc.document_type] || "Документ"}: ${escapeHtml(doc.original_name)}</a>`
  ).join("");
}

async function makeContract() {
  const button = document.querySelector("#makeContract");
  if (button.disabled) return;
  button.disabled = true;
  const originalText = button.textContent;
  button.textContent = "Создаю...";
  try {
    await saveDeal(true);
    const result = await api(`/api/deals/${state.dealId}/contract`, { method: "POST" });
    showMessage(`Excel создан: ${result.template}`);
    window.location.href = result.download_url;
  } finally {
    button.disabled = false;
    button.textContent = originalText;
  }
}

async function reprocessDeal() {
  if (!state.dealId) {
    showMessage("Сначала сохраните сделку и загрузите документы", true);
    return;
  }
  const button = document.querySelector("#reprocessDeal");
  button.disabled = true;
  const originalText = button.textContent;
  button.textContent = "Распознаю...";
  try {
    const result = await api(`/api/deals/${state.dealId}/reprocess`, { method: "POST" });
    for (const [key, value] of Object.entries(result.fields || {})) {
      const field = form.elements.namedItem(key);
      if (field && value) field.value = value;
    }
    applyConfidence(result.field_meta || {});
    form.elements.namedItem("notes").value = result.notes || "";
    await saveDeal(true);
    showMessage(`Обработано документов: ${result.processed}. Проверьте заполненные поля.`);
  } finally {
    button.disabled = false;
    button.textContent = originalText;
  }
}

function escapeHtml(value) {
  return String(value || "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}

document.querySelector("#saveDeal").addEventListener("click", () => saveDeal().catch(e => showMessage(e.message, true)));
document.querySelector("#newDeal").addEventListener("click", newDeal);
document.querySelector("#makeContract").addEventListener("click", () => makeContract().catch(e => showMessage(e.message, true)));
document.querySelector("#reprocessDeal").addEventListener("click", () => reprocessDeal().catch(e => showMessage(e.message, true)));
document.querySelector("#documentFiles").addEventListener("change", e => uploadFiles([...e.target.files]).catch(err => showMessage(err.message, true)));
document.querySelector("#archiveSearch").addEventListener("input", e => loadArchive(e.target.value).catch(err => showMessage(err.message, true)));
document.querySelector("#archiveList").addEventListener("click", e => {
  const item = e.target.closest(".archive-item");
  if (item) openDeal(Number(item.dataset.id)).catch(err => showMessage(err.message, true));
});

newDeal();
loadArchive().catch(e => showMessage(e.message, true));
