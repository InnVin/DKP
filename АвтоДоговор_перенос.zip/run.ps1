$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = "$ProjectRoot\.venv\Scripts\python.exe"

if (-not (Test-Path -LiteralPath $Python)) {
    Write-Host "Сначала выполняется первоначальная установка..." -ForegroundColor Yellow
    & "$ProjectRoot\setup.ps1"
}

Start-Process "http://127.0.0.1:8765"
& $Python -m uvicorn app.main:app --host 127.0.0.1 --port 8765
